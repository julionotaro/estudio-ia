"""
TEMPUS SIMULADO — plataforma de prueba (sin API, sin captcha).

Imita la mecánica de una plataforma web de trámites: login con sesión por
cookie, panel con listado, y un formulario de alta que incluye subida de
archivo. NO es Tempus real; sirve para demostrar el robot Playwright contra
algo realista. Cuando exista acceso a Tempus real, se cambia la URL y los
selectores del robot, no la arquitectura.
"""
from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

from flask import (
    Flask, request, redirect, url_for, session,
    render_template, send_from_directory, abort,
)

BASE = Path(__file__).parent
RECIBIDOS = BASE / "recibidos"
RECIBIDOS.mkdir(exist_ok=True)
DB = RECIBIDOS / "_cargados.json"

app = Flask(__name__)
app.secret_key = "demo-tempus-no-secreto"

# Credenciales de demo (en real: certificado digital)
USUARIO = "gestor"
CLAVE = "demo1234"


def _leer_cargados() -> list[dict]:
    if DB.exists():
        return json.loads(DB.read_text(encoding="utf-8"))
    return []


def _guardar_cargado(reg: dict) -> None:
    data = _leer_cargados()
    data.append(reg)
    DB.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _login_requerido() -> bool:
    return session.get("auth") is True


@app.route("/")
def home():
    if not _login_requerido():
        return redirect(url_for("login"))
    return redirect(url_for("panel"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = ""
    if request.method == "POST":
        if request.form.get("usuario") == USUARIO and request.form.get("clave") == CLAVE:
            session["auth"] = True
            session["usuario"] = USUARIO
            return redirect(url_for("panel"))
        error = "Usuario o clave incorrectos."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/panel")
def panel():
    if not _login_requerido():
        return redirect(url_for("login"))
    return render_template("panel.html", cargados=_leer_cargados(), usuario=session.get("usuario"))


@app.route("/alta", methods=["GET", "POST"])
def alta():
    if not _login_requerido():
        return redirect(url_for("login"))
    if request.method == "POST":
        archivo = request.files.get("documento")
        nombre_guardado = ""
        if archivo and archivo.filename:
            nombre_guardado = f"{datetime.now():%Y%m%d%H%M%S}_{archivo.filename}"
            archivo.save(RECIBIDOS / nombre_guardado)

        reg = {
            "num_presentacion": f"{len(_leer_cargados()) + 1:05d}",
            "tipo": request.form.get("tipo", ""),
            "matricula": request.form.get("matricula", "").upper().replace(" ", ""),
            "bastidor": request.form.get("bastidor", "").upper().replace(" ", ""),
            "nif_adquirente": request.form.get("nif_adquirente", ""),
            "nombre_adquirente": request.form.get("nombre_adquirente", ""),
            "gestoria": request.form.get("gestoria", ""),
            "documento_recibido": nombre_guardado,
            "cargado_at": datetime.now().isoformat(timespec="seconds"),
        }
        _guardar_cargado(reg)
        return redirect(url_for("panel", ok=reg["matricula"]))
    return render_template("alta.html")


@app.route("/recibidos/<nombre>")
def ver_recibido(nombre):
    if not _login_requerido():
        abort(403)
    return send_from_directory(RECIBIDOS, nombre)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5055, debug=False)
