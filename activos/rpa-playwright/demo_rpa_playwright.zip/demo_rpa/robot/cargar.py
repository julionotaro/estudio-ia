"""
ROBOT DE CARGA — Playwright sobre la plataforma simulada.

Demuestra la mecánica de RPA web sobre una plataforma sin API:
  1. Abre un navegador real (Chromium).
  2. Detecta si la sesión está viva; si no, hace login (paso asistible en real).
  3. Por cada trámite de la base de origen, abre el formulario de alta,
     rellena los campos, adjunta el PDF y guarda.
  4. Verifica que el panel refleje cada carga.
  5. Captura una screenshot por hito para evidencia.

En real solo cambian: la URL base, los selectores (data-id de los campos de
Tempus) y el login (sustituido por sesión con certificado ya abierta por un
humano). La estructura del robot es la misma.

Uso:
    python3 robot/cargar.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright, Page, TimeoutError as PWTimeout

BASE = Path(__file__).resolve().parent.parent
DATOS = BASE / "datos" / "tramites.json"
UPLOADS = BASE / "uploads_robot"
SHOTS = BASE / "salida" / "capturas"
SHOTS.mkdir(parents=True, exist_ok=True)

URL = "http://127.0.0.1:5055"
USUARIO = "gestor"
CLAVE = "demo1234"

HEADLESS = "--headed" not in sys.argv  # por defecto headless; --headed para verlo


def _shot(page: Page, nombre: str) -> None:
    ruta = SHOTS / f"{nombre}.png"
    page.screenshot(path=str(ruta), full_page=True)
    print(f"   📸 captura: {ruta.name}")


def sesion_viva(page: Page) -> bool:
    """La sesión está viva si /panel no nos redirige a /login."""
    page.goto(f"{URL}/panel", wait_until="networkidle")
    return "/login" not in page.url


def login(page: Page) -> None:
    print("→ Sesión no activa. Haciendo login…")
    page.goto(f"{URL}/login", wait_until="networkidle")
    page.fill("#usuario", USUARIO)
    page.fill("#clave", CLAVE)
    _shot(page, "01_login_completado")
    page.click("#btn-entrar")
    page.wait_for_url(f"{URL}/panel", timeout=5000)
    print("   ✓ Login correcto.")
    _shot(page, "02_panel_inicial")


def cargar_tramite(page: Page, t: dict, i: int) -> None:
    print(f"→ Cargando {t['id']} · {t['matricula']} ({t['tipo']})")
    page.goto(f"{URL}/alta", wait_until="networkidle")

    page.select_option("#tipo", t["tipo"])
    page.fill("#matricula", t["matricula"])
    page.fill("#bastidor", t["bastidor"])
    page.fill("#nif_adquirente", t["nif_adquirente"])
    page.fill("#nombre_adquirente", t["nombre_adquirente"])
    page.fill("#gestoria", t["gestoria"])

    pdf = UPLOADS / t["documento"]
    if not pdf.exists():
        raise FileNotFoundError(f"No existe el PDF a subir: {pdf}")
    page.set_input_files("#documento", str(pdf))
    _shot(page, f"03_alta_{i:02d}_{t['matricula']}")

    page.click("#btn-guardar")
    page.wait_for_url(f"{URL}/panel**", timeout=5000)
    print(f"   ✓ {t['matricula']} cargado y documento adjuntado.")


def verificar(page: Page, esperados: list[dict]) -> bool:
    page.goto(f"{URL}/panel", wait_until="networkidle")
    cuerpo = page.inner_text("body")
    ok = True
    for t in esperados:
        presente = t["matricula"] in cuerpo
        print(f"   {'✓' if presente else '✗'} {t['matricula']} en panel")
        ok = ok and presente
    _shot(page, "99_panel_final")
    return ok


def main() -> int:
    tramites = json.loads(DATOS.read_text(encoding="utf-8"))
    print(f"Base de origen: {len(tramites)} trámites a cargar.\n")

    with sync_playwright() as p:
        navegador = p.chromium.launch(headless=HEADLESS)
        contexto = navegador.new_context(accept_downloads=True)
        page = contexto.new_page()

        try:
            if not sesion_viva(page):
                login(page)
            else:
                print("→ Sesión ya activa, se reutiliza.")

            for i, t in enumerate(tramites, 1):
                cargar_tramite(page, t, i)

            print("\n→ Verificando panel…")
            todo_ok = verificar(page, tramites)

        except PWTimeout as e:
            print(f"\n✗ Timeout: la página no respondió como se esperaba.\n{e}")
            _shot(page, "error_timeout")
            return 2
        finally:
            contexto.close()
            navegador.close()

    print("\n" + ("✓ DEMO OK: todos los trámites cargados y verificados."
                   if todo_ok else "✗ Faltan trámites en el panel."))
    return 0 if todo_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
