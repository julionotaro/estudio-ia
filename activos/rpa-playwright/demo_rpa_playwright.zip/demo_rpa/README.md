# Demo RPA — carga en plataforma web sin API (Playwright)

Demuestra la mecánica de automatización de una plataforma web sin API:
**login → carga de datos → subida de archivo → verificación**, todo sin tocar
el ratón. La "plataforma" es un Tempus simulado (Flask). El robot es Playwright.

Cuando exista acceso a Tempus real, solo cambian tres cosas en `robot/cargar.py`:
la URL base, los selectores de los campos, y el login (que se reemplaza por una
sesión con certificado abierta por un humano). La estructura del robot es la misma.

## Estructura

```
demo_rpa/
  datos/tramites.json        Base de origen (qué cargar). Cámbiala por tu fuente.
  tempus_sim/app.py          Plataforma simulada: login, panel, alta + subida.
  tempus_sim/recibidos/      Lo que el servidor recibe (PDFs + _cargados.json).
  robot/cargar.py            El robot Playwright.
  uploads_robot/             PDFs que el robot adjunta.
  salida/capturas/           Screenshots que el robot genera como evidencia.
```

## Requisitos (una vez)

```bash
pip install playwright flask reportlab
python3 -m playwright install chromium
```

## Cómo correrlo

**1. Arrancar la plataforma simulada** (una terminal):
```bash
cd tempus_sim
python3 app.py
# queda escuchando en http://127.0.0.1:5055  (usuario: gestor / clave: demo1234)
```

**2. Correr el robot** (otra terminal):
```bash
python3 robot/cargar.py            # headless (sin ventana)
python3 robot/cargar.py --headed   # con ventana, para verlo navegar
```

El robot loguea, da de alta los 3 trámites de `datos/tramites.json` adjuntando
su PDF, y verifica que aparezcan en el panel. Las capturas quedan en
`salida/capturas/`.

## Qué demuestra cada pieza (mecánica de Playwright)

- `page.goto(url)` — navegar a una página.
- `page.fill("#campo", valor)` — escribir en un input localizado por su id.
- `page.select_option("#tipo", valor)` — elegir en un desplegable.
- `page.set_input_files("#documento", ruta)` — **adjuntar un archivo** (esto es
  la subida; Playwright entrega el archivo al input file sin diálogo del SO).
- `page.click("#boton")` — pulsar.
- `page.wait_for_url(...)` — esperar la navegación tras guardar.
- `sesion_viva()` — detecta si la sesión cayó (si /panel redirige a /login).
  En real, aquí es donde el robot avisaría a un humano para re-loguear.

## Para conectarlo a algo real más adelante

1. Cambiar `datos/tramites.json` por la fuente real (export de tu sistema, BD, API interna).
2. En `robot/cargar.py`: cambiar `URL`, los selectores (`#matricula`, etc.) por
   los reales de la plataforma, y sustituir `login()` por reutilización de una
   sesión con certificado ya abierta (perfil persistente de navegador).
3. Orquestar con cron / n8n: "cada día a las X, corré el robot; si falla, avisá".
